package com.example.myapplication;

public class ListItem {

    private String listItem;
    private int image;

    public ListItem(String listItem, int image) {
        this.listItem = listItem;
        this.image = image;
    }

    public String getListItem(){
        return listItem;
    }

    public int getImage(){
        return image;
    }
}
