package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.AutoCompleteTextView;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    private List<ListItem> listItems;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        fillItemList();

        AutoCompleteTextView autoCompleteTextView = findViewById(R.id.autoComplete);
        ListItemArrayAdapter adapter = new ListItemArrayAdapter(this,listItems);
        autoCompleteTextView.setAdapter(adapter);


    }

    private void fillItemList(){

        listItems = new ArrayList<>();
        listItems.add(new ListItem("Hospital", R.drawable.baseline_local_hospital_black_18dp));
        listItems.add(new ListItem("Library",R.drawable.baseline_local_library_black_18dp));
        listItems.add(new ListItem("School",R.drawable.baseline_school_black_18dp));
        listItems.add(new ListItem("Store",R.drawable.baseline_store_black_18dp));

    }

}
