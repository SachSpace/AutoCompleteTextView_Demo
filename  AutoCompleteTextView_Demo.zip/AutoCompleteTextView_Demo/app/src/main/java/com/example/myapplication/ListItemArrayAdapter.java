package com.example.myapplication;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Filter;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;

import java.util.ArrayList;
import java.util.List;

public class ListItemArrayAdapter extends ArrayAdapter<ListItem> {

    private  List<ListItem> listItemsAll;

    public ListItemArrayAdapter(@NonNull Context context, @NonNull List<ListItem> listItems) {
        super(context, 0, listItems);
        listItemsAll = new ArrayList<>(listItems);
    }
    @NonNull
    @Override
    public Filter getFilter(){
        return listFilter;
    }

    @NonNull
    @Override
    public View getView(int position,  View convertView, ViewGroup parent){
        if(convertView == null){
            convertView = LayoutInflater.from(getContext()).inflate(R.layout.row_format,parent,false);
        }

        TextView textView = convertView.findViewById(R.id.textView);
        ImageView imageView = convertView.findViewById(R.id.imageView);

        ListItem listItem = getItem(position);

        if(listItem != null){
            textView.setText(listItem.getListItem());
            imageView.setImageResource(listItem.getImage());
        }

       return convertView;
    }

    private Filter listFilter = new Filter() {
        @Override
        protected FilterResults performFiltering(CharSequence constraint) {
            FilterResults results = new FilterResults();
            List <ListItem> suggestion = new ArrayList<>();

            if(constraint == null || constraint.length()==0){
                suggestion.addAll(listItemsAll);
            } else {
                String filterText = constraint.toString().toLowerCase().trim();
                for(ListItem item : listItemsAll){
                    if(item.getListItem().toLowerCase().contains(filterText)){
                        suggestion.add(item); //this is pop up list items
                    }
                }
            }

            results.values = suggestion;
            results.count = suggestion.size();
            return results;
        }

        @Override
        protected void publishResults(CharSequence constraint, FilterResults results) {
            clear();
            addAll((List) results.values);
            notifyDataSetChanged();

        }

        @Override
        public CharSequence convertResultToString(Object resultValue) {
            return ((ListItem) resultValue).getListItem();
        }
    };

}
